import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default class AppHeader extends React.Component {
render() {
return (
<View style={styles.viewStyle}>

</View>
);
}
}

const styles = StyleSheet.create({
viewStyle: {
backgroundColor: '#66F2ED',
alignItems: 'center',
marginBottom: 0,
marginTop: 0
},

})