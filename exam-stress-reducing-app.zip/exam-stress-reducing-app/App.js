import React from 'react';
import { StyleSheet, Text, View, Image } from 'react-native';
import DescriptionScreen from './screens/DescriptionScreen';
import AppHeader from './components/AppHeader';
import HomeScreen from './screens/HomeScreen';
import BeforeExamScreen from './screens/BeforeExamScreen';
import OralExamScreen from './screens/OralExamScreen';
import TheExamScreen from './screens/TheExamScreen';
import DistractionScreen from './screens/DistractionScreen';
import BreathingScreen from './screens/BreathingScreen';
import ExercisesScreen from './screens/ExercisesScreen';
import InfoScreen from './screens/InfoScreen';
import WrittenExamScreen from './screens/WrittenExamScreen';
import AfterExamScreen from './screens/AfterExamScreen';
import StudyTechniquesScreen from './screens/StudyTechniquesScreen';
import FallAsleepScreen from './screens/FallAsleepScreen';
import StudyPlanScreen from './screens/StudyPlanScreen';
import HOPScreen from './screens/HOPScreen';
import ReadingScreen from './screens/ReadingScreen';
import AdviceScreen from './screens/AdviceScreen';

import { createSwitchNavigator, createAppContainer } from 'react-navigation';
import { createBottomTabNavigator } from 'react-navigation-tabs';

export default function App() {
  return (
    <View>
      <AppHeader />
      <Container />
    </View>
  );
}

const Navigator = createSwitchNavigator({
  DescriptionScreen: DescriptionScreen,
  HomeScreen: HomeScreen,
  ExercisesScreen: ExercisesScreen,
  BreathingScreen: BreathingScreen,
  InfoScreen: InfoScreen,
  DistractionScreen: DistractionScreen,
  TheExamScreen: TheExamScreen,
  BeforeExamScreen: BeforeExamScreen,
  OralExamScreen: OralExamScreen,
  WrittenExamScreen: WrittenExamScreen,
  AfterExamScreen: AfterExamScreen,
  StudyTechniquesScreen: StudyTechniquesScreen,
  FallAsleepScreen: FallAsleepScreen,
  StudyPlanScreen: StudyPlanScreen,
  HOPScreen: HOPScreen,
  ReadingScreen: ReadingScreen,
  AdviceScreen: AdviceScreen,
});

const Container = createAppContainer(Navigator);
