import React from 'react';
import { View, TouchableOpacity, Text, Image, StyleSheet } from 'react-native';

export default class TheExamScreen extends React.Component {
  render() {
    return (
      <View style={{ backgroundColor: 'white' }}>
        <Image style={styles.img} source={require('../assets/exams.jpg')} />

        <TouchableOpacity
          style={[styles.button, { backgroundColor: '#FBEFB7' }]}
          onPress={() => {
            this.props.navigation.navigate('BeforeExamScreen');
          }}>
          <Text style={styles.textStyle}>The Day Before Exam</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.button, { backgroundColor: '#FBEFB7' }]}
          onPress={() => {
            this.props.navigation.navigate('OralExamScreen');
          }}>
          <Text style={styles.textStyle}>Oral Exams</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.button, { backgroundColor: '#FBEFB7' }]}
          onPress={() => {
            this.props.navigation.navigate('WrittenExamScreen');
          }}>
          <Text style={styles.textStyle}>Written Exams</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.button2, { backgroundColor: '#FBEFB7' }]}
          onPress={() => {
            this.props.navigation.navigate('AfterExamScreen');
          }}>
          <Text style={styles.textStyle}>After the Exams</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.buttonStyle}
          onPress={() => {
            this.props.navigation.navigate('HomeScreen');
          }}>
          <Text style={styles.textStyle1}>Back</Text>
        </TouchableOpacity>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  img: {
    marginTop: 0,
    width: 320,
    height: 150,
  },

  button: {
    width: 300,
    height: 50,
    marginTop: 30,
    marginLeft: 10,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 25,
    backgroundColor: 'white',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 8,
    },
    shadowOpacity: 0.3,
    shadowRadius: 10.32,
    elevation: 16,
  },

  button2: {
    width: 300,
    height: 50,
    marginTop: 30,
    marginLeft: 10,
    marginBottom: 110,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 25,
    backgroundColor: 'white',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 8,
    },
    shadowOpacity: 0.3,
    shadowRadius: 10.32,
    elevation: 16,
  },

  buttonStyle: {
    backgroundColor: '#FBEFB7',
    borderColor: 'black',
    fontSize: 25,
    fontWeight: 'bold',
    borderWidth: 4,
    marginTop: 45,
    marginLeft: 85,
    alignItems: 'center',
    justifyContent: 'center',
    width: 150,
    height: 60,
    borderRadius: 80,
    marginBottom: 10,
  },

  textStyle1: {
    color: 'black',
    marginRight: 12,
    marginLeft: 12,
    fontSize: 20,
    marginBottom: 4,
    fontWeight: 'bold',
  },

  textStyle: {
    color: 'black',
    fontSize: 20,
    fontWeight: 'bold',
    fontFamily: 'times',
  },
});
