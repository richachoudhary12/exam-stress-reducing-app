import React from 'react';
import { View, Image, TouchableOpacity, Text, StyleSheet } from 'react-native';

export default class InfoScreen extends React.Component {
  render() {
    return (
      <View style={{ backgroundColor: '#FFB6C1' }}>
        <Text style={styles.head}>The Physical</Text>

        <Text style={styles.head1}>1. Walk around the buiding</Text>

        <Image style={styles.img} source={require('../assets/walking.jpg')} />

        <Text style={styles.textStyle}>
          You will get fresh air , day light and new ideas and at the same time
          you'll get away from all the temptetions such as the internet,
          Facebook , and other activities that remove your focus from your work.
        </Text>

        <Text style={styles.head1}>2. Balance exercises</Text>

        <Image style={styles.img} source={require('../assets/balance.jpg')} />

        <Text style={styles.textStyle}>
          Stand on one leg for 30 seconds. Avoid arching your back.Make sure
          that both thighs are vertical.
        </Text>

        <Text style={styles.head1}>3. Do Pushups</Text>

        <Image style={styles.img} source={require('../assets/girl.jpg')} />

        <Text style={styles.textStyle}>
          Do 10 Pushups and get the circulation going.
        </Text>

        <Text style={styles.head1}>4. Stand On Your Head</Text>

        <Image
          style={styles.img}
          source={require('../assets/standOnHead.png')}
        />

        <Text style={styles.textStyle}>Stand on your head, if you can!!!</Text>

        <Text style={styles.head1}>5. Stairs</Text>

        <Image
          style={styles.img1}
          source={require('../assets/climbingStairs.jpg')}
        />

        <Text style={styles.textStyle}>Walk up and down the stairs.</Text>

        <Text style={styles.head1}>6. Relaxation</Text>

        <Image style={styles.img2} source={require('../assets/relax.jpg')} />

        <Text style={styles.textStyle}>
          Interlace your fingers and turn your palms outward, and stretch the
          arms forward. Curve yor back and hold the stretch for 30 seconds. Move
          your arms above your head, hold the stretch upward and a little
          backwards and hold this for 30 seconds.
        </Text>

        <Text style={styles.textStyle}>
          Pull your shoulders up above your ears, so your back gets rounded,
          and then pull your hands as far as back as possible. Hold it for 4
          seconds and repeat this 8 times.
        </Text>

        <Text style={styles.head1}>7. Circulation of the Arms</Text>

        <Image
          style={styles.img}
          source={require('../assets/circulation.jpg')}
        />

        <Text style={styles.textStyle}>
          Stetch both arms to the side, keeping them at shoulder height, palms
          facing up. Turn the shoulders forwards, while the arms are still
          pointing to the sides. Turn the arms around, so the palms faces up. Turn
          them back again. Repeat this 8 times.
        </Text>

        <Text style={styles.head1}>8. Relaxation of the neck</Text>

        <Image style={styles.img3} source={require('../assets/neck.jpg')} />

        <Text style={styles.textStyle}>Give some relaxation to your neck.</Text>

        <TouchableOpacity
          style={styles.buttonStyle}
          onPress={() => {
            this.props.navigation.navigate('ExercisesScreen');
          }}>
          <Text style={styles.textStyle1}>Back</Text>
        </TouchableOpacity>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  img: {
    marginTop: 0,
    width: 316,
    height: 350,
  },

  img1: {
    marginTop: 0,
    width: 316,
    height: 300,
  },

  img2: {
    marginTop: 0,
    width: 310,
    height: 190,
  },

  img3: {
    marginTop: 0,
    width: 316,
    height: 170,
  },

  textStyle: {
    color: 'black',
    marginRight: 12,
    marginLeft: 12,
    fontSize: 20,
    marginBottom: 0,
    fontWeight: 'normal',
  },

  buttonStyle: {
    borderColor: '#5e3d9f',
    fontSize: 25,
    fontWeight: 'bold',
    borderWidth: 4,
    marginTop: 45,
    marginLeft: 85,
    backgroundColor: 'white',
    alignItems: 'center',
    justifyContent: 'center',
    width: 150,
    height: 60,
    borderRadius: 80,
    marginBottom: 10,
  },

  head1: {
    marginTop: 10,
    fontWeight: 'normal',
    textAlign: 'center',
    fontSize: 40,
    color: '#301934',
    marginBottom: 20,
  },

  textStyle1: {
    color: '#5e3d9f',
    marginRight: 12,
    marginLeft: 12,
    fontSize: 20,
    marginBottom: 4,
    fontWeight: 'bold',
  },

  head: {
    fontWeight: 'bold',
    textAlign: 'center',
    fontSize: 60,
    marginBottom: 5,
    backgroundColor: '#b19cd9',
    marginTop: 0,
  },
});
