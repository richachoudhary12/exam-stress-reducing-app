import React from 'react';
import { View, Image, TouchableOpacity, Text, StyleSheet } from 'react-native';
import { Audio } from 'expo-av';

const source = require('../Sounds/05 Mindfulness of Breath.mp3');

export default class BreathingScreen extends React.Component {
  state = {
    playingStatus: 'Play',
  };

  async _playRecording() {
    const { sound } = await Audio.Sound.create(
      source,
      {
        shouldPlay: true,
        isLooping: true,
      },
      this._updateScreenForSoundStatus
    );
    this.sound = sound;
    this.setState({
      playingStatus: 'Playing',
    });
  }

  _updateScreenForSoundStatus = (status) => {
    if (status.isPlaying && this.state.playingStatus !== 'Playing') {
      this.setState({ playingStatus: 'playing' });
    } else if (!status.isPlaying && this.state.playingStatus === 'Playing') {
      this.setState({ playingStatus: 'Paused' });
    }
  };

  async _pauseAndPlayRecording() {
    if (this.sound != null) {
      if (this.state.playingStatus == 'Playing') {
        console.log('pausing...');
        await this.sound.pauseAsync();
        console.log('paused!');
        this.setState({
          playingStatus: 'Paused',
        });
      } else {
        console.log('Playing...');
        await this.sound.playAsync();
        console.log('Playing!');
        this.setState({
          playingStatus: 'Playing',
        });
      }
    }
  }

  _syncPauseAndPlayRecording() {
    if (this.sound != null) {
      if (this.state.playingStatus == 'Playing') {
        this.sound.pauseAsync();
      } else {
        this.sound.playAsync();
      }
    }
  }

  _playAndPause = () => {
    switch (this.state.playingStatus) {
      case 'Play':
        this._playRecording();
        break;
      case 'Paused':
      case 'Playing':
        this._pauseAndPlayRecording();
        break;
    }
  };

  render() {
    return (
      <View style={{ backgroundColor: '#FFB6C1' }}>
        <Text style={styles.head}>Just Breathe</Text>

        <Image style={styles.img} source={require('../assets/Breathing.png')} />

        <TouchableOpacity
          style={styles.buttonStyle}
          onPress={this._playAndPause}>
          <Text style={styles.textStyle1}>{this.state.playingStatus}</Text>
        </TouchableOpacity>

        <Text style={styles.textStyle}>
          Sit quietly on a chair with both feet on the ground and your hands in
          your lap. Allow yourself to feel centred in the chair. Bring all of
          your attention to the physical act of breathing. Start to notice the
          breath as it enters your body through your nose and travels to your
          lungs. Notice with curiosity whether the inward and outward breaths
          are cool or warm, and notice where the breath travels as it enters and
          departs.
        </Text>

        <Text style={styles.textStyle}>
          Also notice the breath as your lungs relax and you inhale through your
          nose. Don’t try to do anything with your breathing – simply notice it,
          pay attention to it and be aware of it. It doesn’t matter if your
          breathing is slow or fast, deep or shallow; it just is what it is.
          Allow your body to do what it does naturally.
        </Text>

        <Text style={styles.textStyle}>
          You will start to notice that each time you breathe in, your diaphragm
          or stomach will expand… and each time you breathe out your diaphragm
          or stomach will relax. Again, don’t try to do anything – just be aware
          of the physical sensations of breathing in and breathing out. If you
          find that thoughts intrude, this is okay. Don’t worry, just notice the
          thoughts, allow them to be, and gently bring your awareness back to
          your breath.
        </Text>

        <Text style={styles.textStyle}>
          Start this exercise initially for 5 minutes, building up daily. You
          can also do this exercise lying down in bed if you have difficulty
          sleeping. It is simply a way of allowing you to have more mindful and
          conscious awareness of your body and its surroundings, its breathing
          and its capacity to relax. When our breathing relaxes our muscles
          relax.
        </Text>

        <TouchableOpacity
          style={styles.buttonStyle}
          onPress={() => {
            this.props.navigation.navigate('ExercisesScreen');
          }}>
          <Text style={styles.textStyle1}>Back</Text>
        </TouchableOpacity>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  img: {
    marginLeft: 0,
    width: 310,
    height: 215,
  },

  textStyle1: {
    color: '#5e3d9f',
    marginRight: 12,
    marginLeft: 12,
    fontSize: 20,
    marginBottom: 4,
    fontWeight: 'bold',
  },

  textStyle: {
    color: 'black',
    marginRight: 12,
    marginLeft: 12,
    fontSize: 20,
    marginBottom: 0,
    fontWeight: 'normal',
  },

  buttonStyle: {
    borderColor: '#5e3d9f',
    fontSize: 25,
    fontWeight: 'bold',
    borderWidth: 4,
    marginTop: 45,
    marginLeft: 85,
    backgroundColor: 'white',
    alignItems: 'center',
    justifyContent: 'center',
    width: 150,
    height: 60,
    borderRadius: 80,
    marginBottom: 10,
  },

  head: {
    fontWeight: 'bold',
    textAlign: 'center',
    fontSize: 40,
    marginBottom: 5,
    backgroundColor: '#b19cd9',
    marginTop: 0,
  },
});
