import React from 'react';
import { View, TouchableOpacity, Text, Image, StyleSheet } from 'react-native';

export default class StudyTechniquesScreen extends React.Component {
  render() {
    return (
      <View style={{ backgroundColor: 'white' }}>
        <Image
          style={styles.img}
          source={require('../assets/StudyTechiniques.jpg')}
        />

        <TouchableOpacity
          style={[styles.button, { backgroundColor: '#3A7F55' }]}
          onPress={() => {
            this.props.navigation.navigate('FallAsleepScreen');
          }}>
          <Text style={styles.textStyle}>Better Sleep</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.button, { backgroundColor: '#3A7F55' }]}
          onPress={() => {
            this.props.navigation.navigate('StudyPlanScreen');
          }}>
          <Text style={styles.textStyle}>Make a plan for the week</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.button, { backgroundColor: '#3A7F55' }]}
          onPress={() => {
            this.props.navigation.navigate('HOPScreen');
          }}>
          <Text style={styles.textStyle}>HOP Strategy</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.button, { backgroundColor: '#3A7F55' }]}
          onPress={() => {
            this.props.navigation.navigate('ReadingScreen');
          }}>
          <Text style={styles.textStyle}>How much should you read</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.button2, { backgroundColor: '#3A7F55' }]}
          onPress={() => {
            this.props.navigation.navigate('AdviceScreen');
          }}>
          <Text style={styles.textStyle}>Good Advice</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.buttonStyle}
          onPress={() => {
            this.props.navigation.navigate('HomeScreen');
          }}>
          <Text style={styles.textStyle1}>Back</Text>
        </TouchableOpacity>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  img: {
    marginTop: 0,
    width: 319,
    height: 180,
  },

  button: {
    width: 300,
    height: 50,
    marginTop: 30,
    marginLeft: 10,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 25,
    backgroundColor: 'white',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 8,
    },
    shadowOpacity: 0.3,
    shadowRadius: 10.32,
    elevation: 16,
  },

  buttonStyle: {
    borderColor: '#2C5F2D',
    fontSize: 25,
    fontWeight: 'bold',
    borderWidth: 4,
    marginTop: 45,
    marginLeft: 85,
    backgroundColor: 'white',
    alignItems: 'center',
    justifyContent: 'center',
    width: 150,
    height: 60,
    borderRadius: 80,
    marginBottom: 10,
  },

  textStyle1: {
    color: '#2C5F2D',
    marginRight: 12,
    marginLeft: 12,
    fontSize: 20,
    marginBottom: 4,
    fontWeight: 'bold',
  },

  button2: {
    buttonColor: '#FFC0CB',
    width: 300,
    height: 50,
    marginTop: 30,
    marginLeft: 10,
    marginBottom: 50,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 25,
    backgroundColor: 'white',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 8,
    },
    shadowOpacity: 0.3,
    shadowRadius: 10.32,
    elevation: 16,
  },

  textStyle: {
    color: '#AFC7B9',
    fontSize: 20,
    fontWeight: 'bold',
    fontFamily: 'times',
  },
});
