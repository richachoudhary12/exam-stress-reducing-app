import React from 'react';
import { View, Image, TouchableOpacity, Text, StyleSheet } from 'react-native';

export default class AdviceScreen extends React.Component {
  render() {
    return (
      <View style={{ backgroundColor: '#5CB37F' }}>
        <Text style={styles.head}>Good Advices</Text>

        <Text style={styles.head1}>1. Focus on what you have managed</Text>

        <Image style={styles.img} source={require('../assets/Contended.png')} />

        <Text style={styles.textStyle}>
          Spend 10 minutes on thinking about what you have managed today.It
          helps you not to focus on all things you haven't managed - the things
          that it were perhaps too dificult to manage.
        </Text>

        <Text style={styles.head1}>2. Accept your anxiety</Text>

        <Image style={styles.img1} source={require('../assets/Happy.jpg')} />

        <Text style={styles.textStyle}>
          Accept that a certain amount of anxiety and stress can actually help
          improve your performance. Accept that being nervous is part of being
          human.By saying it out loud it will take up less space inside you.
        </Text>

        <Text style={styles.head1}>3. Drop the negative thoughts</Text>

        <Image style={styles.img1} source={require('../assets/Anxiety.jpg')} />

        <Text style={styles.textStyle}>
          Do you suffer from negative thoughts? Try to correct the negative
          thoughts,so that they become more realistic .
        </Text>

        <Text style={styles.textStyle}>
          Formulate positive and supportive thoughts about yourself and your
          accomplishments instead. Would you for example say to a friend, that
          his thoughts about being stupid were correct? And that he would
          definitely fail?
        </Text>

        <Text style={styles.head1}>4. Avoid all-or-nothing thinking</Text>

        <Image style={styles.img} source={require('../assets/Thinking.jpg')} />

        <Text style={styles.textStyle}>
          Practise nuanced thinking instead of extreme thinking - think
          inclusively rather than "all or nothing". Having read 80% of the
          curriculum is more than enough to pass.
        </Text>

        <Text style={styles.head1}>5. Visualition exercises</Text>

        <Image
          style={styles.img1}
          source={require('../assets/Visualize.jpg')}
        />

        <Text style={styles.textStyle}>
          Imagine the situation of the exam, and imagine yourself manage it well
          This is a kind of mental trainning exercise, that a lot of sports
          people use successfully.
        </Text>

        <Text style={styles.head1}>6. Use your study group/partner</Text>

        <Image
          style={styles.img2}
          source={require('../assets/StudyPartner.jpg')}
        />

        <Text style={styles.textStyle}>
          Manage you performance anxiety by practicing making presentation of
          the topic to your study group or in twos.
        </Text>

        <Text style={styles.head1}>7. Exercise</Text>

        <Image style={styles.img} source={require('../assets/Exercise.jpg')} />

        <Text style={styles.textStyle}>
          It prevents depression,stress and anxiety. Find a type of exercise
          that you like and put it into your weekly schedule as a fixed point
          that cannot be changed.
        </Text>

        <Text style={styles.head1}>8. Remove "noise" </Text>

        <Image style={styles.img3} source={require('../assets/Noise.jpg')} />

        <Text style={styles.textStyle}>
          Switch off the mobile and the internet. Don't use Facebook and don't
          Facebook and don't check private mails until you are back home and off
          from your studies. These are delaying tactics that destroy your
          ability to concentrate.
        </Text>

        <Text style={styles.head1}>See the big picture</Text>

        <Text style={styles.textStyle}>
          Start off your day by making an outline of the day, and end the day by
          looking back at what you have achieved. Make a realistic to-do-list
          that lists activities according to priority:
        </Text>

        <Text style={styles.textStyle2}>
          • Things/tasks that have to be done today
        </Text>

        <Text style={styles.textStyle2}>
          • Things that can be done tomorrow
        </Text>

        <Text style={styles.textStyle2}>
          • Things that can wait until next month
        </Text>

        <Text style={styles.textStyle2}>
          • Things that can be fixed when you get a chance
        </Text>

        <Text style={styles.textStyle2}>
          • Things that can be done when you have finished your education
        </Text>

        <Text style={styles.head1}>Start your day in a day in a good way</Text>

        <Text style={styles.textStyle}>
          Make sure you get up at the same time every day.It is a good idea to
          avoid TV in the morning.
        </Text>

        <Text style={styles.head1}>Eat well</Text>

        <Image style={styles.img1} source={require('../assets/food.jpg')} />

        <Text style={styles.textStyle}>
          The closer you get to the exam, the more important it is that you eat
          well.You need nourishment in order to perform well.In other words, eat
          lots of healthy food and less sugar,coffee and alcohol.
        </Text>

        <TouchableOpacity
          style={styles.buttonStyle}
          onPress={() => {
            this.props.navigation.navigate('StudyTechniquesScreen');
          }}>
          <Text style={styles.textStyle3}>Back</Text>
        </TouchableOpacity>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  img: {
    marginTop: 0,
    width: 315,
    height: 250,
  },

  img1: {
    marginTop: 0,
    width: 315,
    height: 270,
  },

  img2: {
    marginTop: 0,
    width: 315,
    height: 190,
  },

  img3: {
    marginTop: 0,
    width: 315,
    height: 170,
  },

  textStyle: {
    color: 'black',
    marginRight: 12,
    marginLeft: 12,
    fontSize: 20,
    marginBottom: 0,
    fontWeight: 'normal',
  },

  buttonStyle: {
    borderColor: '#154A2A',
    fontSize: 25,
    fontWeight: 'bold',
    borderWidth: 4,
    marginTop: 45,
    marginLeft: 85,
    backgroundColor: 'white',
    alignItems: 'center',
    justifyContent: 'center',
    width: 150,
    height: 60,
    borderRadius: 80,
    marginBottom: 10,
  },

  textStyle2: {
    color: 'black',
    marginRight: 12,
    marginLeft: 12,
    fontSize: 20,
    marginBottom: 20,
    fontWeight: 'normal',
  },

  head1: {
    marginTop: 10,
    fontWeight: 'normal',
    textAlign: 'center',
    fontSize: 40,
    color: '#301934',
    marginBottom: 20,
  },

  head: {
    color: '#154A2A',
    fontWeight: 'bold',
    textAlign: 'center',
    fontSize: 50,
    marginBottom: 20,
    backgroundColor: '#AFC7B9',
    marginTop: 0,
  },

  textStyle3: {
    color: '#154A2A',
    marginRight: 12,
    marginLeft: 12,
    fontSize: 20,
    marginBottom: 4,
    fontWeight: 'bold',
  },
});
