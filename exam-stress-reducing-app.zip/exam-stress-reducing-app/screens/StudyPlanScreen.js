import React from 'react';
import { View, Image, TouchableOpacity, Text, StyleSheet } from 'react-native';

export default class StudyPlanScreen extends React.Component {
  render() {
    return (
      <View style={{ backgroundColor: '#5CB37F' }}>
        <Text style={styles.head}>Make a plan for the week</Text>

        <Image
          style={styles.img}
          source={require('../assets/MakingStudyPlan.png')}
        />

        <Text style={styles.head1}>
          1.Plan a schedule of planned activities
        </Text>

        <Text style={styles.textStyle}>
          • School life has many aspects. Some of the most common are fixed:
          EATING, CLASSES, CAMPUS ORGANIZATIONS, WORK.
        </Text>

        <Text style={styles.textStyle}>
          • Many are flexible: SLEEPING, STUDYING, RECREATION, PERSONAL.
        </Text>

        <Text style={styles.head1}>
          2. Plan enough time for studying each subject
        </Text>

        <Text style={styles.textStyle}>
          • Most School classes are planned to require about three hours work
          per week per credit in the course. By multiplying your credit load by
          three you can get a good idea of the time you should provide for
          studying in addition to time spent in class.
        </Text>

        <Text style={styles.head1}>
          3. Study at a set time and in a consistent place.
        </Text>

        <Text style={styles.textStyle}>
          • Establishing habits of study is extremely important. Knowing what
          and when you are going to study saves a lot of time in making
          decisions and retracing your steps to get necessary materials, etc
        </Text>

        <Text style={styles.textStyle}>
          • Avoid generalizations in your schedule, such as "study chemistry" at
          certain regular hours. Instead, plan to "complete ten equations" or
          "read and take notes on chapter 6 for Chemistry." Treat your study
          time as you would attend a class: don’t miss it unless you’re sick,
          have a family emergency, etc. It should be a permanent part of your
          daily routine.
        </Text>

        <Text style={styles.head1}>
          4. Study as soon after your class as possible.
        </Text>

        <Text style={styles.textStyle}>
          • One hour spent shortly after class will do as much good in
          developing an understanding and memory of materials as several hours a
          few days later. Re-­copy/type notes while they are still fresh in your
          mind; fill in the gaps. Start assignments while your memory of the
          assignment is still accurate. By doing this, it will be easier to
          transfer information from short -­term to long-­term memory.
        </Text>

        <Text style={styles.head1}>
          5. Utilize odd hours during the day for studying
        </Text>

        <Text style={styles.textStyle}>
          • The scattered one or two hour free periods between classes are
          easily wasted. Planning to use them for studying for the class just
          finished will result in free time for recreation and other activities
          at other times in the week. Make use of daylight hours. Research shows
          that what you can accomplish in one hour during the day can take one
          ­and-­a-­half hours at night. In general, our minds and bodies are
          ready to “wind down” at night rather than “gear up” for work.
        </Text>

        <Text style={styles.head1}>
          6. Limit your study time to not more than 2 hours on any one course at
          one time
        </Text>

        <Text style={styles.textStyle}>
          • After 1 to 2 hours of study you begin to tire rapidly and your
          ability to concentrate decreases rapidly. Taking a break and then
          switching to another course will provide the change necessary to keep
          up your efficiency. Do difficult work when your mind is most fresh.
          For some students, it is in the morning; for others it is in the late
          afternoon. Space out your study periods and take appropriate breaks
          (e.g., 10 -­ 15 minutes after 1-­ 1 ½ hours of study).
        </Text>

        <Text style={styles.head1}>7. Trade time - don't steal it it.</Text>

        <Text style={styles.textStyle}>
          • When unexpected events arise that take up time you had planned to
          study, decide immediately where you can find the time to make up the
          missed study time and adjust your schedule for that week. Also, make
          good use of weekend evenings. This "trading agreement" provides for
          committing one night to study, but rotating it as recreational
          possibilities vary.
        </Text>

        <Text style={styles.head1}>8. Provide for spaced review </Text>

        <Text style={styles.textStyle}>
          • Schedule one day per week to review the work in each of your courses
          and be sure you are up -­to-­date. This review should be cumulative,
          covering briefly all the work done thus far in the semester. This may
          take only 10 -­ 20 minutes per class. This will save your time later
          when you are preparing for tests/finals
        </Text>

        <Text style={styles.head1}>9. Review, Recite !</Text>

        <Text style={styles.textStyle}>
          • Organize your notes in a question and answer form, and think in
          terms of questions and answers about the main ideas of the material as
          you review weekly. When preparing for exams, try to predict the
          questions the instructor may ask. Reviewing and reciting increase
          memory. This will save time in the long run.
        </Text>

        <Text style={styles.head1}>
          10. Keep carefully organized notes on both lectures and assignments.
        </Text>

        <Text style={styles.textStyle}>
          • Good notes are the best basis for review. Watch for key ideas in
          lectures and try to express them in your own words in your notes. Know
          when assignments are given and when they are due. It may help to date
          them and number the pages
        </Text>

        <Text style={styles.head1}>
          11. Leave some unscheduled time for flexibility.
        </Text>

        <Text style={styles.textStyle}>
          • Lack of flexibility is one of the main reasons students do not
          follow a schedule. Make your schedule and stick to it. Remember that
          it usually takes 30 days to establish a habit.
        </Text>

        <TouchableOpacity
          style={styles.buttonStyle}
          onPress={() => {
            this.props.navigation.navigate('StudyTechniquesScreen');
          }}>
          <Text style={styles.textStyle1}>Back</Text>
        </TouchableOpacity>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  img: {
    marginLeft: 0,
    marginBottom: 30,
    width: 315,
    height: 225,
  },

  textStyle1: {
    color: '#154A2A',
    marginRight: 12,
    marginLeft: 12,
    fontSize: 20,
    marginBottom: 4,
    fontWeight: 'bold',
  },

  textStyle: {
    color: 'black',
    marginRight: 12,
    marginLeft: 12,
    fontSize: 20,
    marginBottom: 0,
    fontWeight: 'normal',
  },

  buttonStyle: {
    borderColor: '#154A2A',
    fontSize: 25,
    fontWeight: 'bold',
    borderWidth: 4,
    marginTop: 45,
    marginLeft: 85,
    backgroundColor: 'white',
    alignItems: 'center',
    justifyContent: 'center',
    width: 150,
    height: 60,
    borderRadius: 80,
    marginBottom: 10,
  },

  buttonStyle2: {
    borderColor: '#154A2A',
    fontSize: 25,
    fontWeight: 'bold',
    borderWidth: 4,
    marginTop: 45,
    marginLeft: 85,
    backgroundColor: 'white',
    alignItems: 'center',
    justifyContent: 'center',
    width: 150,
    height: 60,
    borderRadius: 80,
    marginBottom: 30,
  },

  head: {
    color: '#154A2A',
    fontWeight: 'bold',
    textAlign: 'center',
    fontSize: 50,
    marginBottom: 20,
    backgroundColor: '#AFC7B9',
    marginTop: 0,
  },

  head1: {
    marginTop: 10,
    fontWeight: 'normal',
    textAlign: 'center',
    fontSize: 40,
    color: '#301934',
    marginBottom: 20,
  },
});
