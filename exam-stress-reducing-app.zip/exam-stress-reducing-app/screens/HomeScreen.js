import React from 'react';
import { View, TouchableOpacity, Text, Image, StyleSheet } from 'react-native';

export default class HomeScreen extends React.Component {
  render() {
    return (
      <View style={{ backgroundColor: 'white' }}>
        <View style={styles.viewStyle1}>
          <Text style={styles.textStyle1}>Exam stress Reducing App</Text>
        </View>

        <TouchableOpacity
          style={[styles.button, { backgroundColor: '#D3D3D3' }]}
          onPress={() => {
            this.props.navigation.navigate('ExercisesScreen');
          }}>
          <Text style={styles.textStyle}>Calm Down</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.button, { backgroundColor: '#D3D3D3' }]}
          onPress={() => {
            this.props.navigation.navigate('TheExamScreen');
          }}>
          <Text style={styles.textStyle}>The Exam</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.button2, { backgroundColor: '#D3D3D3' }]}
          onPress={() => {
            this.props.navigation.navigate('StudyTechniquesScreen');
          }}>
          <Text style={styles.textStyle}>Study Techniques</Text>
        </TouchableOpacity>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  button: {
    color: '#FFC0CB',
    width: 300,
    height: 50,
    marginLeft: 15,
    marginTop: 30,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 25,
    backgroundColor: 'white',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 8,
    },
    shadowOpacity: 0.3,
    shadowRadius: 10.32,
    elevation: 16,
  },

  button2: {
    buttonColor: '#FFC0CB',
    width: 300,
    height: 50,
    marginLeft: 15,
    marginTop: 30,
    marginBottom: 60,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 25,
    backgroundColor: 'white',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 8,
    },
    shadowOpacity: 0.3,
    shadowRadius: 10.32,
    elevation: 16,
  },

  textStyle: {
    fontSize: 20,
    fontWeight: 'bold',
    fontFamily: 'times',
  },

  viewStyle1: {
    backgroundColor: '#66F2ED',
    alignItems: 'center',
    marginBottom: 30,
    marginTop: 0,
  },

  textStyle1: {
    fontSize: 40,
    fontWeight: 'bold',
  },

  img2: {
    marginTop: 0,
    width: 40,
    height: 40,
  },
});
