import React from 'react';
import {
  View,
  Image,
  TouchableOpacity,
  Text,
  StyleSheet,
  TouchableHighlight,
} from 'react-native';
import CountDown from 'react-native-countdown-component';

export default class HOPScreen extends React.Component {
  render() {
    return (
      <View style={{ backgroundColor: '#5CB37F' }}>
        <Text style={styles.head}>HOP Strategy</Text>

        <Image style={styles.img} source={require('../assets/hop.jpg')} />

        <Text style={styles.textStyle}>
          HOP stands for Hour Of Power.
        </Text>

        <Text style={styles.head1}>Read for 45 minutes</Text>

        <Text style={styles.textStyle}>
          It is recommended that you read for a certain amount of time instead of
          counting the pages. Most people skip the breaks, and the result is
          oftenn that the last pages have been read but not understood. You may
          tick off the article, but you know very well that you have not
          understood it and that you will not remember it when the exam comes.
        </Text>

        <Text style={styles.head1}>Have a break for 15 minutes</Text>

        <Text style={styles.textStyle}>
          Spend the breaks away from the computer or other types of input, that
          demands brain capacity - that also means not checking Facebook, mails,
          texts and so on.
        </Text>

        <Text style={styles.textStyle}>
          You have to be physically active in your 15 minutes break. An
          increased blood circulation will improve your concentration and thus
          your ability to memorize.
        </Text>

        <TouchableOpacity
          style={styles.buttonStyle}
          onPress={() => {
            this.props.navigation.navigate('StudyTechniquesScreen');
          }}>
          <Text style={styles.textStyle1}>Back</Text>
        </TouchableOpacity>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  img: {
    marginLeft: 0,
    marginBottom: 30,
    width: 318,
    height: 225,
  },

  textStyle1: {
    color: '#154A2A',
    marginRight: 12,
    marginLeft: 12,
    fontSize: 20,
    marginBottom: 4,
    fontWeight: 'bold',
  },

  textStyle: {
    color: 'black',
    marginRight: 12,
    marginLeft: 12,
    fontSize: 20,
    marginBottom: 0,
    fontWeight: 'normal',
  },

  buttonStyle: {
    borderColor: '#154A2A',
    fontSize: 25,
    fontWeight: 'bold',
    borderWidth: 4,
    marginTop: 45,
    marginLeft: 85,
    backgroundColor: 'white',
    alignItems: 'center',
    justifyContent: 'center',
    width: 150,
    height: 60,
    borderRadius: 80,
    marginBottom: 10,
  },

  buttonStyle2: {
    borderColor: '#154A2A',
    fontSize: 25,
    fontWeight: 'bold',
    borderWidth: 4,
    marginTop: 45,
    marginLeft: 85,
    backgroundColor: 'white',
    alignItems: 'center',
    justifyContent: 'center',
    width: 150,
    height: 60,
    borderRadius: 80,
    marginBottom: 30,
  },

  head: {
    color: '#154A2A',
    fontWeight: 'bold',
    textAlign: 'center',
    fontSize: 50,
    marginBottom: 20,
    backgroundColor: '#AFC7B9',
    marginTop: 0,
  },

  head1: {
    marginTop: 10,
    fontWeight: 'normal',
    textAlign: 'center',
    fontSize: 40,
    color: '#301934',
    marginBottom: 20,
  },
});

const options = {
  container: {
    backgroundColor: '#FF0000',
    padding: 5,
    borderRadius: 5,
    width: 200,
    alignItems: 'center',
  },
  text: {
    fontSize: 25,
    color: '#FFF',
    marginLeft: 7,
  },
};
