import React from 'react';
import { View, Image, TouchableOpacity, Text, StyleSheet } from 'react-native';

export default class WrittenExamScreen extends React.Component {
  render() {
    return (
      <View style={{ backgroundColor: '#FBEFB7' }}>
        <Image
          style={styles.img}
          source={require('../assets/WrittenExam.jpg')}
        />

        <Text style={styles.head}>Written Exams </Text>

        <Text style={styles.textStyle}>
          • Be there on time - not too early, not too late.
        </Text>

        <Text style={styles.textStyle}>
          • Find a space and imagine that you are moving in to that space.
          Arrange your books,pens and food and drink how you like it.
        </Text>

        <Text style={styles.textStyle}>
          • If you let yourself distracted by others easily, it is a good idea
          to find yourself a space at the front of the room , so you can't look
          at the person in front of you.
        </Text>

        <Text style={styles.textStyle}>
          • Remember to breathe into the stomach. Spend some time before the
          exam papers are handed out to do a breathing exercise. This can be
          done very discretely without anybody noticing.
        </Text>

        <Text style={styles.textStyle}>
          • Do the exam questions in the following order:-
        </Text>

        <Text style={styles.textStyle2}>
          • When you get given the exam paper , start off by reading through all
          the questions.
        </Text>

        <Text style={styles.textStyle2}>
          • Start off with one of the easy questions and leave the more
          difficult ones for later, when you have been getting into the topic
          for a while.
        </Text>

        <Text style={styles.textStyle2}>
          • If there is something you find difficult, then go on to another
          question.Then you can return to the more difficult one later.
        </Text>

        <Text style={styles.textStyle2}>
          • Always choose the easiest question first and then work your way
          through the questions one by one.
        </Text>

        <Text style={styles.textStyle}>
          • While you are at your desk, you may want to do breathing exercises,
          stretching exercises, and focusing exercises in between the questions.
          It will help your brain to switch off and give you a little break. It
          will only take 1-2 minutes to do each exercise.
        </Text>

        <Text style={styles.textStyle}>
          • Answer each question on a seperate sheet. Then it is easy to rewrite
          one of the answers, you find that you have something to add later on.
        </Text>

        <TouchableOpacity
          style={styles.buttonStyle}
          onPress={() => {
            this.props.navigation.navigate('TheExamScreen');
          }}>
          <Text style={styles.textStyle1}>Back</Text>
        </TouchableOpacity>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  img: {
    marginLeft: 0,
    width: 315,
    height: 220,
  },

  textStyle: {
    color: 'black',
    marginRight: 12,
    marginBottom: 10,
    marginLeft: 12,
    fontSize: 20,
    marginBottom: 50,
    fontWeight: 'normal',
  },

  textStyle2: {
    color: 'black',
    marginRight: 12,
    marginBottom: 10,
    marginLeft: 50,
    fontSize: 20,
    marginBottom: 30,
    fontWeight: 'normal',
  },
  textStyle1: {
    color: 'black',
    marginRight: 12,
    marginLeft: 12,
    fontSize: 20,
    marginBottom: 4,
    fontWeight: 'bold',
  },

  buttonStyle: {
    fontSize: 25,
    fontWeight: 'bold',
    borderWidth: 4,
    marginTop: 45,
    marginLeft: 85,
    backgroundColor: 'white',
    alignItems: 'center',
    justifyContent: 'center',
    width: 150,
    height: 60,
    borderRadius: 80,
    marginBottom: 10,
  },

  head: {
    color: '#FBEFB7',
    fontWeight: 'bold',
    textAlign: 'center',
    fontSize: 30,
    marginBottom: 40,
    backgroundColor: 'black',
    marginTop: 0,
  },
});
