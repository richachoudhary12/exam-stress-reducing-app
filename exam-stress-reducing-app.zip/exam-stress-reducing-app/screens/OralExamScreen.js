import React from 'react';
import { View, Image, TouchableOpacity, Text, StyleSheet } from 'react-native';

export default class OralExamScreen extends React.Component {
  render() {
    return (
      <View style={{ backgroundColor: '#FBEFB7' }}>
        <Image style={styles.img} source={require('../assets/OralExam.jpg')} />

        <Text style={styles.head}>Oral Exams </Text>

        <Text style={styles.textStyle}>
          • Be there on time. If you are there too early, you will have too
          much time to think, and if you are there just before the exam you may
          risk becoming stressed out or being late.
        </Text>

        <Text style={styles.textStyle}>
          • If you discover that you are there a long time before the exam
          starts, you may want to take a walk in the surrounding area, until it
          is your turn.
        </Text>

        <Text style={styles.textStyle}>
          • Do the breathing exercises before you go on.These exercises may be
          done quietly and discretely.
        </Text>

        <Text style={styles.textStyle}>
          • You may want to go somewhere quiet and do some stretching exercises.
        </Text>

        <Text style={styles.textStyle}>
          • Be aware how you sit down during the exam. Sit down on the chair and
          feel the sest and back of the chair that support you. Put your feet
          flat on the ground. Breathe deeply into the stomach.
        </Text>

        <Text style={styles.textStyle}>
          • Remember that in a natural conversation, it is normal to take small
          breaks to think about things
        </Text>

        <Text style={styles.textStyle}>
          • Remember that small breaks, hmms, that you use to clear your throat
          , etc. seem more problematic to you than others.
        </Text>

        <Text style={styles.textStyle}>
          • It may be a good idea to say "I don't remember", rather than "I
          don't know".
        </Text>

        <Text style={styles.textStyle}>
          • If you need a break to think , you may want yourself to drink
          water. That also helps if you have a dry mouth.
        </Text>

        <Text style={styles.textStyle}>
          • If you are asked a question you don't know the answer to, then ask
          the examiner or censor to ask the question again and if possible
          reformulate it.
        </Text>

        <TouchableOpacity
          style={styles.buttonStyle}
          onPress={() => {
            this.props.navigation.navigate('TheExamScreen');
          }}>
          <Text style={styles.textStyle1}>Back</Text>
        </TouchableOpacity>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  img: {
    marginLeft: 0,
    width: 315,
    height: 220,
  },

  textStyle: {
    color: 'black',
    marginRight: 12,
    marginBottom: 10,
    marginLeft: 12,
    fontSize: 20,
    marginBottom: 50,
    fontWeight: 'normal',
  },

  textStyle1: {
    color: 'black',
    marginRight: 12,
    marginLeft: 12,
    fontSize: 20,
    marginBottom: 4,
    fontWeight: 'bold',
  },

  buttonStyle: {
    fontSize: 25,
    fontWeight: 'bold',
    borderWidth: 4,
    marginTop: 45,
    marginLeft: 85,
    backgroundColor: 'white',
    alignItems: 'center',
    justifyContent: 'center',
    width: 150,
    height: 60,
    borderRadius: 80,
    marginBottom: 10,
  },

  head: {
    color: '#FBEFB7',
    fontWeight: 'bold',
    textAlign: 'center',
    fontSize: 30,
    marginBottom: 40,
    backgroundColor: 'black',
    marginTop: 0,
  },
});
