import React from 'react';
import { View, Image, TouchableOpacity, Text, StyleSheet } from 'react-native';

export default class DistractionScreen extends React.Component {
  render() {
    return (
      <View style={{ backgroundColor: '#FFB6C1' }}>
        <Text style={styles.head}>Exercise of Distraction</Text>

        <Text style={styles.head1}>1. Find round shapes</Text>

        <Image style={styles.img} source={require('../assets/round.jpg')} />

        <Text style={styles.textStyle}>
          Scan your surroundings,and look for round shapes.
        </Text>

        <Text style={styles.head1}>2. Listen to the sounds around you</Text>

        <Image style={styles.img} source={require('../assets/ear.jpg')} />

        <Text style={styles.textStyle}>
          Guide you attention to the sounds around you.How many different sounds
          can you hear, and how loud are they.
        </Text>

        <Text style={styles.head1}>3. STOP</Text>

        <Image style={styles.img} source={require('../assets/stop.jpg')} />

        <Text style={styles.textStyle}>
          Say it aloud or within yourself.Stop!!
        </Text>

        <Text style={styles.textStyle}>Breathe!</Text>
        <Text style={styles.textStyle}>Observe!</Text>
        <Text style={styles.textStyle}>Try again!</Text>

        <Text style={styles.head1}>4. Count anything</Text>

        <Image style={styles.img} source={require('../assets/number.png')} />

        <Text style={styles.textStyle}>
          You may count the windows in the the buildings across the street,or
          subtract 7 from 64 and go backwards from there, etc.
        </Text>

        <Text style={styles.head1}>5. Listen to music</Text>

        <Image style={styles.img} source={require('../assets/notes.jpg')} />

        <Text style={styles.textStyle}>
          Listen to some music,that usually makes you happy or sing your
          favourite tune.
        </Text>

        <Text style={styles.head1}>6. Feel</Text>

        <Image style={styles.img2} source={require('../assets/hands.jpg')} />

        <Text style={styles.textStyle}>
          Guide your attention to your hands and feel the things that are within
          your reach with your fingertips.
        </Text>

        <Text style={styles.textStyle}>
          How does the material your clothes,the surface of the chair or the
          armrest feel.
        </Text>

        <Text style={styles.head1}>7. Scan your surroundings</Text>

        <Image style={styles.img1} source={require('../assets/eye.jpg')} />

        <Text style={styles.textStyle}>
          Scan your surroundings with your eyes.Stop at every single thing
          and say aloud to yourself what you are
          seeing(lamp,vase,table,door,etc.)
        </Text>

        <TouchableOpacity
          style={styles.buttonStyle}
          onPress={() => {
            this.props.navigation.navigate('ExercisesScreen');
          }}>
          <Text style={styles.textStyle1}>Back</Text>
        </TouchableOpacity>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  img: {
    marginTop: 0,
    width: 316,
    height: 350,
  },

  img1: {
    marginTop: 0,
    width: 316,
    height: 300,
  },

  img2: {
    marginTop: 0,
    width: 316,
    height: 300,
  },

  textStyle: {
    color: 'black',
    marginRight: 12,
    marginLeft: 12,
    fontSize: 20,
    marginBottom: 0,
    fontWeight: 'normal',
  },

  buttonStyle: {
    borderColor: '#5e3d9f',
    fontSize: 25,
    fontWeight: 'bold',
    borderWidth: 4,
    marginTop: 45,
    marginLeft: 85,
    backgroundColor: 'white',
    alignItems: 'center',
    justifyContent: 'center',
    width: 150,
    height: 60,
    borderRadius: 80,
    marginBottom: 10,
  },

  head1: {
    marginTop: 10,
    fontWeight: 'normal',
    textAlign: 'center',
    fontSize: 40,
    color: '#301934',
    marginBottom: 20,
  },

  textStyle1: {
    color: '#5e3d9f',
    marginRight: 12,
    marginLeft: 12,
    fontSize: 20,
    marginBottom: 4,
    fontWeight: 'bold',
  },

  head: {
    fontWeight: 'bold',
    textAlign: 'center',
    fontSize: 60,
    marginBottom: 5,
    backgroundColor: '#b19cd9',
    marginTop: 0,
  },
});
