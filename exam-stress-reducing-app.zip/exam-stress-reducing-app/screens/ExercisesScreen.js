import React from 'react';
import { View, TouchableOpacity, Text, Image, StyleSheet } from 'react-native';

export default class ExercisesScreen extends React.Component {
  render() {
    return (
      <View style={{ backgroundColor: 'white' }}>
        <Image style={styles.img} source={require('../assets/CalmDown.jpg')} />

        <TouchableOpacity
          style={[styles.button, { backgroundColor: '#FFB6C1' }]}
          onPress={() => {
            this.props.navigation.navigate('BreathingScreen');
          }}>
          <Text style={styles.textStyle}>Breathing</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.button, { backgroundColor: '#FFB6C1' }]}
          onPress={() => {
            this.props.navigation.navigate('InfoScreen');
          }}>
          <Text style={styles.textStyle}>Physical Exercises</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.button2, { backgroundColor: '#FFB6C1' }]}
          onPress={() => {
            this.props.navigation.navigate('DistractionScreen');
          }}>
          <Text style={styles.textStyle}>Exercises of Distraction</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.buttonStyle}
          onPress={() => {
            this.props.navigation.navigate('HomeScreen');
          }}>
          <Text style={styles.textStyle1}>Back</Text>
        </TouchableOpacity>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  img: {
    marginTop: 0,
    width: 319,
    height: 150,
  },

  button: {
    color: '#FFC0CB',
    width: 300,
    height: 50,
    marginTop: 30,
    marginLeft: 10,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 25,
    backgroundColor: 'white',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 8,
    },
    shadowOpacity: 0.3,
    shadowRadius: 10.32,
    elevation: 16,
  },

  buttonStyle: {
    borderColor: '#5e3d9f',
    fontSize: 25,
    fontWeight: 'bold',
    borderWidth: 4,
    marginTop: 45,
    marginLeft: 85,
    backgroundColor: 'white',
    alignItems: 'center',
    justifyContent: 'center',
    width: 150,
    height: 60,
    borderRadius: 80,
    marginBottom: 10,
  },

  textStyle1: {
    color: '#5e3d9f',
    marginRight: 12,
    marginLeft: 12,
    fontSize: 20,
    marginBottom: 4,
    fontWeight: 'bold',
  },

  button2: {
    buttonColor: '#FFC0CB',
    width: 300,
    height: 50,
    marginTop: 30,
    marginLeft: 10,
    marginBottom: 110,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 25,
    backgroundColor: 'white',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 8,
    },
    shadowOpacity: 0.3,
    shadowRadius: 10.32,
    elevation: 16,
  },

  textStyle: {
    color: '#8565c4',
    fontSize: 20,
    fontWeight: 'bold',
    fontFamily: 'times',
  },
});
