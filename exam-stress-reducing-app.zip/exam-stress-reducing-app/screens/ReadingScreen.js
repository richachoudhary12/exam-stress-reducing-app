import React from 'react';
import { View, Image, TouchableOpacity, Text, StyleSheet } from 'react-native';

export default class ReadingScreen extends React.Component {
  render() {
    return (
      <View style={{ backgroundColor: '#5CB37F' }}>
        <Image style={styles.img} source={require('../assets/Reading.jpg')} />

        <Text style={styles.head}>How much should you read</Text>
        <Text style={styles.textStyle}>
          It varies from couse to course, how big the curriculum is, how much
          you have to read, how much has to be memorized. The amount of classes
          each week set a natural limit as to how many hours you have left for
          studying each day.
        </Text>

        <Text style={styles.textStyle}>
          Start off by filling in a week plan by putting in the classes, work ,
          etc. Then it is easier to see the vacant spaces that you can spend
          studying.
        </Text>

        <Text style={styles.textStyle}>
          Most students who suffer from anxiety in connection with exams, try to
          keep the anxiety down by studying too much or by telling themselves
          that they ought to study more than they do. This kind of thinking
          usually has the opposite effect and can lead to more anxiety.
        </Text>

        <Text style={styles.textStyle}>
          Again the framework that you set for yourself has to be indisputable
          and not negotiable. That means that if you for some reasons start 2
          hours later one day , you must not add 2 hours at the end of the day.
          When you have made a decision that cannot be changed, you'll
          automatically get better at starting on time.
        </Text>

        <Text style={styles.head1}>An example of an 8-hour working day</Text>

        <Text style={styles.textStyle1}>
          9-12 - Studies(lessons,reading,working in groups)
        </Text>

        <Text style={styles.textStyle1}>12-13 - Lunch</Text>

        <Text style={styles.textStyle1}>
          13-16 - Studying(lessons, reading, study groups)
        </Text>

        <Text style={styles.textStyle1}>
          17-24 Time off (exercise, voluntary work,family,friends,time to
          yourself)
        </Text>

        <TouchableOpacity
          style={styles.buttonStyle}
          onPress={() => {
            this.props.navigation.navigate('StudyTechniquesScreen');
          }}>
          <Text style={styles.textStyle2}>Back</Text>
        </TouchableOpacity>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  img: {
    marginLeft: 0,
    width: 316,
    height: 200,
  },

  textStyle: {
    color: 'black',
    marginRight: 12,
    marginLeft: 12,
    fontSize: 20,
    marginBottom: 0,
    fontWeight: 'normal',
  },

  textStyle1: {
    color: 'black',
    marginRight: 12,
    marginLeft: 12,
    fontSize: 20,
    marginBottom: 20,
    fontWeight: 'normal',
  },

  buttonStyle: {
    borderColor: '#154A2A',
    fontSize: 25,
    fontWeight: 'bold',
    borderWidth: 4,
    marginTop: 45,
    marginLeft: 85,
    backgroundColor: 'white',
    alignItems: 'center',
    justifyContent: 'center',
    width: 150,
    height: 60,
    borderRadius: 80,
    marginBottom: 10,
  },

  textStyle2: {
    color: '#154A2A',
    marginRight: 12,
    marginLeft: 12,
    fontSize: 20,
    marginBottom: 4,
    fontWeight: 'bold',
  },

  head: {
    color: '#154A2A',
    fontWeight: 'bold',
    textAlign: 'center',
    fontSize: 50,
    marginBottom: 20,
    backgroundColor: '#AFC7B9',
    marginTop: 0,
  },

  head1: {
    marginTop: 10,
    fontWeight: 'normal',
    textAlign: 'center',
    fontSize: 40,
    color: '#301934',
    marginBottom: 20,
  },
});
