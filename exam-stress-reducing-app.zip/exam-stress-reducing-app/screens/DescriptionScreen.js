import React from 'react';
import { View, Image, TouchableOpacity, Text, StyleSheet } from 'react-native';

export default class DescriptionScreen extends React.Component {
  render() {
    return (
      <View style={{ backgroundColor: '#ADD8E6' }}>
        <Image
          style={styles.img}
          source={require('../assets/high-school-gen.jpg')}
        />

        <Text style={styles.head}>Get help to combat Exam stress</Text>
        <Text style={styles.textStyle}>
          In this app you'll be able to find advice and help for your studies
          both before,during and after exams
        </Text>

        <Text style={styles.textStyle}>
          Many students ask for methods to combat Exam stress (and anxiety).Many
          of them imagine an easy cure , but unfortunately such a cure doesn't
          exist . But luckily there are certain tools that will help most people
          combat stress - short term and long term.
        </Text>

        <Text style={styles.textStyle}>
          In the app,you'll find good advice and practical exercises,that may
          help you ease - both in the weeks before and right up to the exam ,
          but also through the whole semester.Changing the way you think is most
          easily done through changing the way you act . Therefore this app ,
          contains many suggestions as to how to act differently during and
          before exams.
        </Text>

        <Text style={styles.textStyle}>
          In order to feel the effect of your efforts on a longer term , and
          truly change your habits , you have to be prepared to repeat the
          different strategies again and again.
        </Text>

        <TouchableOpacity
          style={styles.buttonStyle}
          onPress={() => {
            this.props.navigation.navigate('HomeScreen');
          }}>
          <Text style={styles.textStyle2}>Proceed</Text>
        </TouchableOpacity>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  img: {
    marginLeft: 0,
    width: 310,
    height: 150,
  },

  textStyle: {
    color: 'black',
    marginRight: 12,
    marginLeft: 12,
    fontSize: 20,
    marginBottom: 0,
    fontWeight: 'normal',
  },

  textStyle2: {
    fontSize: 25,
    fontWeight: 'bold',
    fontFamily: 'times',
    marginBottom: 1,
  },

  head: {
    fontWeight: 'bold',
    textAlign: 'center',
    fontSize: 30,
    marginBottom: 40,
    backgroundColor: 'yellow',
    marginTop: 0,
  },

  buttonStyle: {
    marginLeft: 85,
    borderWidth: 4,
    backgroundColor: 'white',
    alignItems: 'center',
    justifyContent: 'center',
    width: 150,
    height: 70,
    borderRadius: 50,
    marginTop: 35,
  },
});
