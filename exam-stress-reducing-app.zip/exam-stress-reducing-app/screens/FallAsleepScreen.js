import React from 'react';
import { View, Image, TouchableOpacity, Text, StyleSheet } from 'react-native';
import { Audio } from 'expo-av';

const source = require('../Sounds/Sleep.mp3');

export default class FallAsleepScreen extends React.Component {
  state = {
    playingStatus: 'Play',
  };

  async _playRecording() {
    const { sound } = await Audio.Sound.create(
      source,
      {
        shouldPlay: true,
        isLooping: true,
      },
      this._updateScreenForSoundStatus
    );
    this.sound = sound;
    this.setState({
      playingStatus: 'Playing',
    });
  }

  _updateScreenForSoundStatus = (status) => {
    if (status.isPlaying && this.state.playingStatus !== 'Playing') {
      this.setState({ playingStatus: 'playing' });
    } else if (!status.isPlaying && this.state.playingStatus === 'Playing') {
      this.setState({ playingStatus: 'Paused' });
    }
  };

  async _pauseAndPlayRecording() {
    if (this.sound != null) {
      if (this.state.playingStatus == 'Playing') {
        console.log('pausing...');
        await this.sound.pauseAsync();
        console.log('paused!');
        this.setState({
          playingStatus: 'Paused',
        });
      } else {
        console.log('Playing...');
        await this.sound.playAsync();
        console.log('Playing!');
        this.setState({
          playingStatus: 'Playing',
        });
      }
    }
  }

  _syncPauseAndPlayRecording() {
    if (this.sound != null) {
      if (this.state.playingStatus == 'Playing') {
        this.sound.pauseAsync();
      } else {
        this.sound.playAsync();
      }
    }
  }

  _playAndPause = () => {
    switch (this.state.playingStatus) {
      case 'Play':
        this._playRecording();
        break;
      case 'Paused':
      case 'Playing':
        this._pauseAndPlayRecording();
        break;
    }
  };

  render() {
    return (
      <View style={{ backgroundColor: '#5CB37F' }}>
        <Text style={styles.head}>Fall Asleep</Text>

        <Image style={styles.img} source={require('../assets/sleeping.jpg')} />

        <Text style={styles.textStyle}>
          A lack of sleep and not feeling properly rested is one of the most
          typical symptoms of stress and one of the most commonly felt
          reactions.
        </Text>

        <Text style={styles.textStyle}>
          Many people experience that it is a big challenge to manage sleep
          patterns. It may feel like a vicious circle, because the more you need
          to sleep, the harder it becomes to fall asleep.
        </Text>

        <Text style={styles.textStyle}>
          Below you will find a number of recommendations that we suggest that
          you combine with the sound recording in the app.
        </Text>

        <TouchableOpacity
          style={styles.buttonStyle2}
          onPress={this._playAndPause}>
          <Text style={styles.textStyle1}>{this.state.playingStatus}</Text>
        </TouchableOpacity>

        <Text style={styles.head1}>Regularity</Text>

        <Text style={styles.textStyle}>
          You must go to bed and get out of bed on the same time every day -
          also on the weekends and during holidays - plus/minus one hour.
        </Text>

        <Text style={styles.textStyle}>
          You have to get up on the same time every day, no matter how little or
          how much you have slept. Your inner clock (and sleeping patterns) will
          be disturbed if you reset it to a new hour everyday. Avoid sleeping
          during the day.
        </Text>

        <Text style={styles.head1}>Calm Down</Text>

        <Text style={styles.textStyle}>
          Create a sleeping ritual for yourself in which you slowly calm down,
          while you approach your usual bedtime : Read a book, take a shower,
          get a massage, use the relaxation techniques, etc.
        </Text>

        <Text style={styles.textStyle}>
          In other words, don't study in front of the computer just before going
          to bed, because that will keep you awake.
        </Text>

        <Text style={styles.head1}>No exercise in the evenning</Text>

        <Text style={styles.textStyle}>
          When you do exercise your pulse and your blood pressure will rise and
          your body produces hormones and sugar, which gives you energy and
          makes it difficult to fall asleep.
        </Text>

        <Text style={styles.textStyle}>
          No trainning before 3 hours of bedtime. Physical activities during the
          day are on the hand, good for your sleeping patterns.
        </Text>

        <Text style={styles.head1}>Avoid light and noise at night</Text>

        <Text style={styles.textStyle}>
          Make Sure you get outdoor light during the day and avoid strong light
          during the night. Make sure, that your bedroom is dark. If you get up
          during the night, try not to switch on the light.
        </Text>

        <Text style={styles.head1}>Sleep in a cool place</Text>

        <Text style={styles.textStyle}>
          Make sure the room temperature in your bedroom is pleasant and low -
          preferably between 13 and 18 degrees.
        </Text>

        <Text style={styles.head1}>Think about something pleasant</Text>

        <Text style={styles.textStyle}>
          Worries and thoughts, that make you angry, frustrated or worried may
          go around and around in your head, and those thoughts should be
          stopped. Therefore, think about something nice. Make it into a habit
          to think about at least three good things that have happened during
          the day, and write them down in a small book(positive diary).
        </Text>

        <Text style={styles.head1}>Avoid food and stimulants</Text>

        <Text style={styles.textStyle}>
          Don't go to bed hungry, but eat at the latest two hours before
          bedtime. Avoid big meals before bedtime. Coffee makes you ignore the
          tiredness in your body.Reduce the amount of coffee you drink,
          especially at night. Drink herbal tea, water or hot milk instead.
        </Text>

        <Text style={styles.head1}>If you can't sleep , get up</Text>

        <Text style={styles.textStyle}>
          If you have been lying awake in your bed for more than an hour, get up
          and do something quiet. Read a book, take a hot shower etc. Avoid
          strong light. Your bed for is sleeping.
        </Text>

        <Text style={styles.head1}>If the good advice doesn't work</Text>

        <Text style={styles.textStyle}>
          Go to see a doctor to find out if there is a physical reason that you
          have problems sleeping, for example, high blood pressure, snoring or
          problems with your digestion, or psycological reasons such as
          depression, anxiety or restlessness.
        </Text>

        <TouchableOpacity
          style={styles.buttonStyle}
          onPress={() => {
            this.props.navigation.navigate('StudyTechniquesScreen');
          }}>
          <Text style={styles.textStyle1}>Back</Text>
        </TouchableOpacity>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  img: {
    marginLeft: 0,
    marginBottom: 30,
    width: 316,
    height: 220,
  },

  textStyle1: {
    color: '#154A2A',
    marginRight: 12,
    marginLeft: 12,
    fontSize: 20,
    marginBottom: 4,
    fontWeight: 'bold',
  },

  textStyle: {
    color: 'black',
    marginRight: 12,
    marginLeft: 20,
    fontSize: 20,
    marginBottom: 0,
    fontWeight: 'normal',
  },

  buttonStyle: {
    borderColor: '#154A2A',
    fontSize: 25,
    fontWeight: 'bold',
    borderWidth: 4,
    marginTop: 45,
    marginLeft: 85,
    backgroundColor: 'white',
    alignItems: 'center',
    justifyContent: 'center',
    width: 150,
    height: 60,
    borderRadius: 80,
    marginBottom: 10,
  },

  buttonStyle2: {
    borderColor: '#154A2A',
    fontSize: 25,
    fontWeight: 'bold',
    borderWidth: 4,
    marginTop: 45,
    marginLeft: 85,
    backgroundColor: 'white',
    alignItems: 'center',
    justifyContent: 'center',
    width: 150,
    height: 60,
    borderRadius: 80,
    marginBottom: 30,
  },

  head: {
    color: '#154A2A',
    fontWeight: 'bold',
    textAlign: 'center',
    fontSize: 50,
    marginBottom: 20,
    backgroundColor: '#AFC7B9',
    marginTop: 0,
  },

  head1: {
    marginTop: 10,
    fontWeight: 'normal',
    textAlign: 'center',
    fontSize: 40,
    color: '#301934',
    marginBottom: 20,
  },
});
