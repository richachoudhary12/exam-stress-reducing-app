import React from 'react';
import { View, Image, TouchableOpacity, Text, StyleSheet } from 'react-native';

export default class AfterExamScreen extends React.Component {
  render() {
    return (
      <View style={{ backgroundColor: '#FBEFB7' }}>
        <Image style={styles.img} source={require('../assets/AfterExam.png')} />

        <Text style={styles.head}>After The Exams </Text>

        <Text style={styles.head1}>Feeling empty after the exam is normal</Text>

        <Text style={styles.textStyle}>
          Many students feel empty once an exam is over. After a big working
          effort over a long period of time you may feel exhausted. For some
          nights, the nightmare continues until the grades have been given.
        </Text>

        <Text style={styles.textStyle}>
          Perhaps you worry a lot and imagine that things have gone wrong, and
          that you are going to fail, etc. Try to stop the negative thoughts,
          because you cannot change the situation anyway, now that the paper has
          been handed in and the exam is over.
        </Text>

        <Text style={styles.head1}>Avoid post-rationalization</Text>

        <Text style={styles.textStyle}>
          After exams many students meet up and discuss exams, marks,
          particular questions and assignments.
        </Text>

        <Text style={styles.textStyle}>
          It may be a good idea not to take part in these discussions, if you
          tend to compare yourself too much to others and perhaps start focusing
          on what they have written, that you didn't write - you may even begin
          to forget what you actually did write.
        </Text>

        <TouchableOpacity
          style={styles.buttonStyle}
          onPress={() => {
            this.props.navigation.navigate('TheExamScreen');
          }}>
          <Text style={styles.textStyle1}>Back</Text>
        </TouchableOpacity>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  img: {
    marginLeft: 0,
    width: 315,
    height: 220,
  },

  textStyle: {
    color: 'black',
    marginRight: 12,
    marginBottom: 10,
    marginLeft: 12,
    fontSize: 20,
    marginBottom: 50,
    fontWeight: 'normal',
  },

  textStyle1: {
    color: 'black',
    marginRight: 12,
    marginLeft: 12,
    fontSize: 20,
    marginBottom: 4,
    fontWeight: 'bold',
  },

  buttonStyle: {
    fontSize: 25,
    fontWeight: 'bold',
    borderWidth: 4,
    marginTop: 45,
    marginLeft: 85,
    backgroundColor: 'white',
    alignItems: 'center',
    justifyContent: 'center',
    width: 150,
    height: 60,
    borderRadius: 80,
    marginBottom: 10,
  },

  head: {
    color: '#FBEFB7',
    fontWeight: 'bold',
    textAlign: 'center',
    fontSize: 30,
    marginBottom: 40,
    backgroundColor: 'black',
    marginTop: 0,
  },

  head1: {
    marginTop: 10,
    fontWeight: 'normal',
    textAlign: 'center',
    fontSize: 40,
    color: '#301934',
    marginBottom: 20,
  },
});
