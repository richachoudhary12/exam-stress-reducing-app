import React from 'react';
import { View, Image, TouchableOpacity, Text, StyleSheet } from 'react-native';

export default class BeforeExamScreen extends React.Component {
  render() {
    return (
      <View style={{ backgroundColor: '#FBEFB7' }}>
        <Image
          style={styles.img}
          source={require('../assets/BeforeExams.jpg')}
        />

        <Text style={styles.head}>The Day Before</Text>

        <Text style={styles.head1}>What works best for you ?</Text>

        <Text style={styles.textStyle}>
          The crucial thing is to find the methods that work best for you, and
          that varies a lot from person to person. That is why, it is impotant
          that you use your own experiences in order to judge what works best
          for you and what doesn't.
        </Text>

        <Text style={styles.head1}>Find about the exam</Text>

        <Text style={styles.textStyle}>
          Prepare yourself by finding out about the exam.Examine the conditions:
          Wher is the exam held? Do you have time to prepare yourself? What are
          you allowed to bring? How long is the exam , and what are you allowed
          to eat and drink?
        </Text>

        <Text style={styles.head1}>What time do you have to set off?</Text>

        <Text style={styles.textStyle}>
          For oral as well as written exams , it is important to be there on
          time. If you are late, you risk getting stressed or being late for the
          exam. If you get there very early, you may become stressed out by the
          atmosphere in front of the examination room.
        </Text>

        <Text style={styles.textStyle}>
          Find out what works best for you : Is it good to talk to others before
          the exams, or does that make you more nervous?
        </Text>

        <TouchableOpacity
          style={styles.buttonStyle}
          onPress={() => {
            this.props.navigation.navigate('TheExamScreen');
          }}>
          <Text style={styles.textStyle1}>Back</Text>
        </TouchableOpacity>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  img: {
    marginLeft: 0,
    width: 315,
    height: 220,
  },

  textStyle: {
    color: 'black',
    marginRight: 12,
    marginLeft: 12,
    fontSize: 20,
    marginBottom: 0,
    fontWeight: 'normal',
  },

  textStyle1: {
    color: 'black',
    marginRight: 12,
    marginLeft: 12,
    fontSize: 20,
    marginBottom: 4,
    fontWeight: 'bold',
  },

  buttonStyle: {
    fontSize: 25,
    fontWeight: 'bold',
    borderWidth: 4,
    marginTop: 45,
    marginLeft: 85,
    backgroundColor: 'white',
    alignItems: 'center',
    justifyContent: 'center',
    width: 150,
    height: 60,
    borderRadius: 80,
    marginBottom: 10,
  },

  head: {
    color: '#FBEFB7',
    fontWeight: 'bold',
    textAlign: 'center',
    fontSize: 30,
    marginBottom: 40,
    backgroundColor: 'black',
    marginTop: 0,
  },

  head1: {
    marginTop: 10,
    fontWeight: 'normal',
    textAlign: 'center',
    fontSize: 40,
    color: '#301934',
    marginBottom: 20,
  },
});
